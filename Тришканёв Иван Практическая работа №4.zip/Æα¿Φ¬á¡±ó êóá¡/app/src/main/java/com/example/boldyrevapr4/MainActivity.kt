package com.example.boldyrevapr4

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import android.view.View
//import android.widget.Toast
import okhttp3.OkHttpClient
import okhttp3.Request
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import android.widget.ProgressBar
import android.widget.ListView
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope

class MainActivity : AppCompatActivity() {
    lateinit var progressBar: ProgressBar
    lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progressBar = findViewById(R.id.progressBar)
        listView = findViewById(R.id.listViewData)
    }

    override fun onResume() {
        super.onResume()
        val client = OkHttpClient()

        val request: Request = Request.Builder()
            .get()
            .url("https://rickandmortyapi.com/api/character")
            .build()

        lifecycleScope.executeAsyncTask(
            onPreExecute = {
                progressBar.visibility = View.VISIBLE
            },
            doInBackground = {
                client.newCall(request).execute().use {
                    if (!it.isSuccessful) {
                        return@executeAsyncTask "code: ${it.code}: ${it.message}"
                    }
                    return@executeAsyncTask it.body.string()
                }
            },
            onPostExecute = {
                try {
                    val moshi = Moshi.Builder().build()
                    val jsonAdapter = moshi.adapter(RootObj::class.java)
                    val rootObj = jsonAdapter.fromJson(it)
                    listView.adapter = CharacterAdapter(this@MainActivity, rootObj!!.characters)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, it, Toast.LENGTH_SHORT).show()
                    Toast.makeText(this@MainActivity, e.message, Toast.LENGTH_SHORT).show()
                } finally {
                    progressBar.visibility = View.GONE
                }
            }
        )
    }
}