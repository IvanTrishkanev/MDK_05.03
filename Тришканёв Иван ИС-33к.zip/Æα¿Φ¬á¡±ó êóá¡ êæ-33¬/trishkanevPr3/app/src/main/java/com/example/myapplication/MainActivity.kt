package com.example.myapplication

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
        private lateinit var databaseHelper: NotesDatabaseHelper
        private lateinit var recyclerView: RecyclerView
        private lateinit var adapter: NotesAdapter
        private var notes = mutableListOf<Note>()
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            databaseHelper = NotesDatabaseHelper(this)

            recyclerView = findViewById(R.id.RecyclerViewNotes)
            recyclerView.layoutManager = LinearLayoutManager(this)

            adapter = NotesAdapter(
                notes = notes,
                onNoteClick = {note -> showNoteDialog(note)},
                onNoteLongClick = {note -> deleteNote(note)}
            )
            recyclerView.adapter = adapter

            loadNotes()

            findViewById<View>(R.id.fabAddNote).setOnClickListener {
                showNoteDialog()
            }
        }
        private fun loadNotes(){
            notes.clear()
            notes.addAll(databaseHelper.getAllNotes())
            adapter.updateNotes(notes)
        }
        private fun showNoteDialog(note: Note? = null) {
            val dialogView = layoutInflater.inflate(R.layout.dialog_note, null)
            val etTitle = dialogView.findViewById<EditText>(R.id.etTitle)
            val etContent = dialogView.findViewById<EditText>(R.id.etContent)

            val isEdit = note != null
            if(isEdit) {
                etTitle.setText(note?.title)
                etContent.setText(note?.content)
            }
            AlertDialog.Builder(this)
                .setTitle(if (isEdit) "Редактировать заметку" else "Новая заметка")
                .setView(dialogView)
                .setPositiveButton("Сохранить") {_,_ ->
                    val title = etTitle.text.toString()
                    val content = etContent.text.toString()

                    if(title.isNotEmpty() && content.isNotEmpty()) {
                        if (isEdit) {

                            val updatedNote = note!!.copy(title = title, content = content)
                            databaseHelper.updateNote(updatedNote)
                        }else{

                            val newNote = Note(title = title, content = content)
                            databaseHelper.addNote(newNote)
                        }
                        loadNotes()
                    }
                }
                .setNeutralButton("Отмена", null)
                .show()
        }
        private fun deleteNote(note: Note) {
            AlertDialog.Builder(this)
                .setTitle("Удаление заметки")
                .setMessage("Вы уверены, что хотите удалить замутку \"${note.title}\"?")
                .setPositiveButton("Удалить") {_,_ ->
                    databaseHelper.deleteNote(note.id)
                    loadNotes()
                }
                .setNeutralButton("Отмена", null)
                .show()
        }

}